
<nav class="navbar navbar-light navbar-expand-lg navbar-light navbar-fixed-top responimg" id="top" role="banner">
	<div class="container">
		<div class="navbar-header">
			<a href="" class="linknav navbar-brand">
				<img alt="logo easy maintenance" src="<?php echo base_url('dist/img/logo_adikari4.png'); ?>">
				<!-- <i class="glyphicon-tint glyphicon"></i> LaundryKu -->
			</a>
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target=".navAwal" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation" style="margin-right:-10%;">
				<span class="navbar-toggler-icon"></span>
			</button>
		</div>
		<div class="collapse navbar-collapse navAwal">
			<ul class="nav navbar-right">
				<li class="linknya"><a class="rf" href="<?php echo site_url('landing/#home'); ?>">Home</a></li>
				<li class="linknya"><a class="rf" href="<?php echo site_url('landing/clients'); ?>">Clients</a></li>
				<li class="linknya"><a class="rf" href="<?php echo site_url('landing/pricing'); ?>">Pricing</a></li>
				<li class="linknya"><a class="rf" href="<?php echo site_url('landing/articles'); ?>">Articles</a></li>
				
				<li class="linknya nav-item dropdown">
					<a class="rf nav-link dropdown-toggle" id="navFeature" data-toggle="dropdown" href="#">Feature</a>
					<div class="dropdown-menu" aria-labelledby="navFeature">
				         <a class="dropdown-item" href="#">Preventive Module</a>
				         <a class="dropdown-item" href="#">Corrective Module</a>
				         <a class="dropdown-item" href="#">Advanced Module</a>
			        </div>
				</li>
				
				<li class="linknya"><a class="rf" href="<?php echo site_url('landing/faq'); ?>">FAQ</a></li>
				<li class="linknya"><a class="rf" target="_blank" href="http://easymaintenance.id/">Demo</a></li>
			</ul>
		</div>
	</div>
</nav>
