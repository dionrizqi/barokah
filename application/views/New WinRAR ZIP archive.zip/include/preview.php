
<div class="konten-preview" id="preview">
<div class="container" style="width:100%;height:100%;">
    <div class="col-md-12">
    <center class="wow bounceInDown"><h1 style="color:#000;font-family: 'Avenir Next';" class="titleMenu"><b>PREVIEW</b></h1> <label>Look Closer at Our Product</label>
    </center>   
<div class="row">
    <div class="col-md-6" style="margin-top: 3%;">
			
		<div id="owl-demo" class="owl-carousel owl-theme">
			<div class="item"><img src="<?php echo base_url('dist/img/demo/1.jpg'); ?>"></div>
			<div class="item"><img src="<?php echo base_url('dist/img/demo/2.jpg'); ?>"> </div>
			<div class="item"><img src="<?php echo base_url('dist/img/demo/3.jpg'); ?>"></div>
		</div>
	
		<a class="left carousel-control" id="prevowl" data-slide="prev">
			<span class="glyphicon glyphicon-chevron-left"></span>
			<span class="sr-only">Previous</span>
		</a>
		<a class="right carousel-control" id="nextowl" data-slide="next">
			<span class="glyphicon glyphicon-chevron-right"></span>
			<span class="sr-only">Next</span>
		</a>
    	
    </div>

    <div class="col-md-6">
    	<div class="row" style="margin: 3%">
    		<h2 style="text-align: center;color:#1a47ac;"><label>What We Offer</label></h2>
    		<img style="width: 100%;" class="responimg" src="<?php echo base_url('dist/img/preview.png'); ?>">
    	</div>
    </div>
 </div>

    
</div>
</div>

 <div style="background: #333;width: 100%;margin-top: 2%" class="responimg">
 	<div style="color: #fff;padding: 3%;">
 		<h4 style="margin-left: 5%;margin-right: 5%"><label>Know us better with this video</label><button style="float: right;" data-toggle="modal" data-target="#mulaiModal" class="btn btn-default mybtn btnlog"><label>Watch Video</label></button></h4>
 		<p style="margin-left: 5%;margin-right: 5%">This video will show you more about Easy Maintenance</p>
 	</div>
 </div>

</div>

<div class="modal fade" id="mulaiModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Easy Maintenance</h4>
        </div>
        
        <div class="modal-body">
        	<iframe style="width: 100%;height: 400px;" class="responimg" src="https://www.youtube.com/embed/t1bIDrIJm5c"></iframe>
        </div>
      
        <div class="modal-footer">
          <button type="button" class="btn btn-default mybtn btnlog" data-dismiss="modal">Close</button>
        </div>
      </div>
      
   </div>
</div>