
<div id="arrow" class="carousel slide" data-ride="carousel" id="home">
	<!-- Indicators -->
	
	<!-- Wrapper for slides -->
	<div class="carousel-inner" role="listbox" style="height:100%;width: 100%;">
		
			
		
		<div class="item active mainbg" style="height:100%;overflow:hidden;width: 100%;">
		<div style="background:rgba(0,0,0,.5);height:100vh;overflow:hidden;width: 100%;">
						
		<div class="row">
		<div id="owl-home" class="owl-carousel owl-theme" style="width: 100%;">
			<div class="item">
				<img alt="home easy maintenance" class="responimg gambar-home" src="<?php echo base_url('dist/img/DSCN0134.jpg'); ?>">
			</div>
			<div class="item">
				<img alt="home easy maintenance 2" class="responimg gambar-home" src="<?php echo base_url('dist/img/th1.jpg'); ?>"> 
			</div>
			<div class="item">
				<img alt="home easy maintenance 3" class="responimg gambar-home" src="<?php echo base_url('dist/img/bg2.jpg'); ?>">
			</div>
		</div>
	
		
		<a class="left carousel-control" id="prevowl-home" data-slide="prev">
			<span class="glyphicon glyphicon-chevron-left"></span>
			<span class="sr-only">Previous</span>
		</a>
		<a class="right carousel-control" id="nextowl-home" data-slide="next">
			<span class="glyphicon glyphicon-chevron-right"></span>
			<span class="sr-only">Next</span>
		</a>
  	
    
		</div>


				<div class="carousel-caption">
					<center class="wow fadeInUp">
						<img class="responimg centered" alt="logo home easy maintenance" src="<?php echo base_url('dist/img/logo_adikari5.png'); ?>"> <br>
						<a href="#whyus" class="rf"><button class="btn btn-default mybtn btnget"><i class="glyphicon-chevron-down glyphicon" style="font-size:2em;"></i></button></a>
					</center>
				</div>
			</div>


	</div>
	</div>
</div>

