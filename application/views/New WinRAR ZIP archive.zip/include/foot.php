</body>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>dist/js/jquery.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>dist/js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>dist/js/wow.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>dist/js/smooth-scroll.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>dist/js/owl.carousel.js"></script>
<script src="<?php echo base_url(); ?>dist/preloader/js/classie.js"></script>
<script src="<?php echo base_url(); ?>dist/preloader/js/pathLoader.js"></script>
<script src="<?php echo base_url(); ?>dist/preloader/js/main.js"></script>
<script  type="text/javascript">
$(function() {
		$('a.rf[href*=#]:not([href=#])').each(function() {
			if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') && location.hostname == this.hostname) {

				var targetId = $(this.hash), targetAnchor = $('[name=' + this.hash.slice(1) +']');
				var target = targetId.length ? targetId : targetAnchor.length ? targetAnchor : false;
				if (target) {
					var targetOffset = target.offset().top;
					$(this).click(function() {
						$(".navbar-nav li a").removeClass("active");
						$(this).addClass('active');
						$('html, body').animate({scrollTop: targetOffset}, 1000);
						return false;
					});
				}
			}
		});
	});

wow = new WOW(
	{
		animateClass: 'animated',
		offset:       100,
	}
);
wow.init();


$(document).ready(function() {
  $("#owl-demo").owlCarousel({
      navigation : false, 
      slideSpeed : 300,
      paginationSpeed : 400,
      singleItem:true,
      autoPlay: 3000,
      pagination: true 
  });
  $("#nextowl").click(function(){
    $("#owl-demo").trigger('owl.next');
  })
  $("#prevowl").click(function(){
    $("#owl-demo").trigger('owl.prev');
  })
});

$(document).ready(function() {
  $("#owl-home").owlCarousel({
      navigation : false, 
      slideSpeed : 300,
      paginationSpeed : 400,
      singleItem:true,
      autoPlay: 3000,
      pagination: true 
  });
  $("#nextowl-home").click(function(){
    $("#owl-home").trigger('owl.next');
  })
  $("#prevowl-home").click(function(){
    $("#owl-home").trigger('owl.prev');
  })
});

$(function () {
  $('[data-toggle="tooltip"]').tooltip()
})

</script>
</html>