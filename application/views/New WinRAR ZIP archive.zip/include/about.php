

<div class="aboutus konten1" id="whyus">
	<div class="container">
		<center class="wow fadeInDown">
			<h1 style="color:#1a47ac;">SMART TOOL FOR YOUR FIELD TEAM</h1>
			<h3><i>Why Easy Maintenance?</i></h3>				
		</center>
	
	<div class="col-md-12" style="margin:5% 5% 0% 7%">
		<center>
			<div class="row">
				<div class="col-md-4 wow fadeInLeft" style="margin-left: -10%;">
					<ul style="list-style-type:none;">
						<li><h2 style="color:#1a47ac;"><img height="50px" width="50px" src="<?php echo base_url('dist/img/logo-e.png'); ?>">  Easy to Access</h2></li>
						<li><label style="width:70%">Access, review, and analyze the data anywhere anytime</label></li>
					</ul>	
						
					<ul style="list-style-type:none;">
						<li><h2 style="color:#1a47ac;"><img height="50px" width="50px" src="<?php echo base_url('dist/img/logo-w.png'); ?>"> Well-documented</h2></li>
						<li><label style="width:70%">Just one click to show all data on your screen. No more wasting time</label></li>
					</ul>
						
						
					<ul style="list-style-type:none;">
						<li><h2 style="color:#1a47ac;"><img height="50px" width="50px" src="<?php echo base_url('dist/img/logo-p.png'); ?>"> Paperless</h2></li>
						<li><label style="width:70%">No more pile of paper on your desk. Everything now on your screen</label></li>
					</ul>
				</div>

				<div class="col-md-5 wow fadeInUp">
					<div class="row">
						<img class="responimg" style="margin-left: 1%;" src="<?php echo base_url('dist/img/emlaptop.png'); ?>">
					</div>
				</div>

				<div class="col-md-3 wow fadeInRight" >
					<ul style="list-style-type:none;">
						<li><h2 style="color:#1a47ac;"><img height="50px" width="50px" src="<?php echo base_url('dist/img/logo-n.png'); ?>"> Notification</h2></li>
						<li><label style="width:100%">All alarm is set based on parameter and notification is sent through dashboard, email, or sms</label></li>
					</ul>

					<ul style="list-style-type:none;">
						<li><h2 style="color:#1a47ac;"><img height="50px" width="50px" src="<?php echo base_url('dist/img/logo-o.png'); ?>"> Online Data Chart</h2></li>
						<li><label style="width:100%">Real time data is now accessible</label></li>
					</ul>
				</div>
			</div>
		</center>
	</div>
	
	</div>
</div>
