<?php $this->load->view('include/head'); ?>
<?php $this->load->view('include/navbar'); ?>
<div style="background: #1a47ac">
	<div style="background: rgba(0,0,0,.5);">
		<div class="container">
			<div class="col-md-12" style="margin:5% auto; max-height: 150px;height:100%;">
				<h1><label class="wow fadeInLeft judul-link">Articles</label></h1>
			</div>
		</div>
	</div>
	
</div>

<div class="aboutus konten1">
	<div class="container">
		<div class="col-md-12" style="margin-top: 2%;">
			<center>
				<div class="row">
					<div class="col-md-4">
					<div class="panel panel-default mypan">
						<div class="panel-body">
							<a href="#">
								<div class="artikel-container">
									<img class="responimg artikel-img" alt="thumbnail artikel easy maintenance" src="<?php echo base_url('dist/img/DSCN0134.png'); ?>">							
									<div class="artikel-overlay judul-konten2">
											<div class="artikel-text"><b>READ MORE</b></div>
									</div>
								</div>
									<h3 class="judul-konten2"><b>Ini Judul Konten</b></h3>
							</a>

							<p style="font-size: .6em;text-transform: uppercase;margin-bottom: -6%;">
								<b>
									BY <a href="#">DION RIZQI</a>.&nbsp 11 MAY 2021 &nbsp
									<i class="glyphicon glyphicon-comment"></i>&nbsp 0
								</b>
							</p>
							<hr>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation...</p>
							<hr>
							<button class="btn btn-default btn-block mybtn btnlog">Read More</button>
						</div>
					</div>
					</div>

					<div class="col-md-4">
					<div class="panel panel-default mypan">
						<div class="panel-body">
							<a href="#">
								<div class="artikel-container">
									<img class="responimg artikel-img" src="<?php echo base_url('dist/img/DSCN0134.png'); ?>">							
									<div class="artikel-overlay judul-konten2">
											<div class="artikel-text"><b>READ MORE</b></div>
									</div>
								</div>
									<h3 class="judul-konten2"><b>Ini Judul Konten</b></h3>
							</a>

							<p style="font-size: .6em;text-transform: uppercase;margin-bottom: -6%;">
								<b>
									BY <a href="#">DION RIZQI</a>.&nbsp 11 MAY 2021 &nbsp
									<i class="glyphicon glyphicon-comment"></i>&nbsp 0
								</b>
							</p>
							<hr>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation...</p>
							<hr>
							<button class="btn btn-default btn-block mybtn btnlog">Read More</button>
						</div>
					</div>
					</div>

					<div class="col-md-4">
					<div class="panel panel-default mypan">
						<div class="panel-body">
							<a href="#">
								<div class="artikel-container">
									<img class="responimg artikel-img" src="<?php echo base_url('dist/img/DSCN0134.png'); ?>">							
									<div class="artikel-overlay judul-konten2">
											<div class="artikel-text"><b>READ MORE</b></div>
									</div>
								</div>
									<h3 class="judul-konten2"><b>Ini Judul Konten</b></h3>
							</a>

							<p style="font-size: .6em;text-transform: uppercase;margin-bottom: -6%;">
								<b>
									BY <a href="#">DION RIZQI</a>.&nbsp 11 MAY 2021 &nbsp
									<i class="glyphicon glyphicon-comment"></i>&nbsp 0
								</b>
							</p>
							<hr>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation...</p>
							<hr>
							<button class="btn btn-default btn-block mybtn btnlog">Read More</button>
						</div>
					</div>
					</div>
				</div>
			</center>
			
		</div>

		<center>
		<nav aria-label="Page navigation example">
			<ul class="pagination">
				<li class="page-item">
					<a class="page-link" href="#" aria-label="Previous">
						<span aria-hidden="true">&laquo;</span>
						<span class="sr-only">Previous</span>
					</a>
				</li>
				
				<li class="page-item"><a class="page-link" href="#">1</a></li>
				<li class="page-item"><a class="page-link" href="#">2</a></li>
				<li class="page-item"><a class="page-link" href="#">3</a></li>
				
				<li class="page-item">
				<a class="page-link" href="#" aria-label="Next">
					<span aria-hidden="true">&raquo;</span>
					<span class="sr-only">Next</span>
				</a>
				</li>
			</ul>
		</nav>
		</center>

	</div>
</div>


<?php $this->load->view('include/foot'); ?>