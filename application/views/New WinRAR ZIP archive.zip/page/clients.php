<?php $this->load->view('include/head'); ?>
<?php $this->load->view('include/navbar'); ?>

<div style="background: #1a47ac">
	<div style="background: rgba(0,0,0,.5);">
		<div class="container">
			<div class="col-md-12" style="margin:5% auto; max-height: 150px;height:100%;">
				<h1><label class="wow fadeInLeft judul-link">Our Clients</label></h1>
			</div>
		</div>
	</div>
	
</div>

<div class="aboutus konten1">
		<div class="container">
			<div class="wow bounceInDown">
				<center>
					<h1><label class="judul-konten1">Meet Our Clients!</label></h1>
					<h3 class="judul-konten2"><i>Some of Easy Maintenance Customers</i></h3>
					<hr>
				</center>
			</div>

			<div class="col-lg-12 col-md-12 col-sm-12" style="margin:10px;">
			<center>
			<div class="row" style="margin-top:5%;">
	            <div class="col-md-4">
	                <a href="#">
	                    <img src="<?php echo base_url('dist/img/clients/chevron.png'); ?>" class="responimg">
	                </a>
	                <!-- <h3> </h3> -->
	                <p></p>
	            </div>
	            <div class="col-md-4">
	                <a href="#">
	                    <img src="<?php echo base_url('dist/img/clients/conocophillips.png'); ?>" class="responimg">
	                </a>
	                <!-- <h3> </h3> -->
	                <p></p>
	            </div>
	            <div class="col-md-4">
	                <a href="#">
	                    <img src="<?php echo base_url('dist/img/clients/petronas.png'); ?>" class="responimg">
	                </a>
	                <!-- <h3> </h3> -->
	                <p></p>
	            </div>
            </div>

            <div class="row responimg" style="margin-top:5%;">
	            <div class="col-md-4">
	                <a href="#">
	                    <img src="<?php echo base_url('dist/img/clients/pertamina.png'); ?>" class="responimg">
	                </a>
	                <!-- <h3> </h3> -->
	                <p></p>
	            </div>
	            <div class="col-md-4">
	                <a href="#">
	                    <img src="<?php echo base_url('dist/img/clients/pertaminawmo.png'); ?>" class="responimg">
	                </a>
	                <!-- <h3> </h3> -->
	                <p></p>
	            </div>
	            <div class="col-md-4">
	                <a href="#">
	                    <img src="<?php echo base_url('dist/img/clients/pertaminaonwj.png'); ?>" class="responimg">
	                </a>
	                <!-- <h3> </h3> -->
	                <p></p>
	            </div>
        	</div>

        	<div class="row responimg" style="margin-top:5%;">
	            <div class="col-md-4">
	                <a href="#">
	                    <img src="<?php echo base_url('dist/img/clients/pertaminageo.png'); ?>" class="responimg">
	                </a>
	                <!-- <h3> </h3> -->
	                <p></p>
	            </div>
	            <div class="col-md-4">
	                <a href="#">
	                    <img src="<?php echo base_url('dist/img/clients/medco.png'); ?>" class="responimg">
	                </a>
	                <!-- <h3> </h3> -->
	                <p></p>
	            </div>
	            <div class="col-md-4">
	                <a href="#">
	                    <img src="<?php echo base_url('dist/img/clients/pln.png'); ?>" class="responimg">
	                </a>
	                <!-- <h3> </h3> -->
	                <p></p>
	            </div>
	        </div>

	        <div class="row responimg" style="margin-top:5%;">
	            <div class="col-md-4">
	                <a href="#">
	                    <img src="<?php echo base_url('dist/img/clients/gde.png'); ?>" class="responimg">
	                </a>
	                <!-- <h3> </h3> -->
	                <p></p>
	            </div>
	            <div class="col-md-4">
	                <a href="#">
	                    <img src="<?php echo base_url('dist/img/clients/rekind.png'); ?>" class="responimg">
	                </a>
	                <!-- <h3> </h3> -->
	                <p></p>
	            </div>
	            <div class="col-md-4">
	                <a href="#">
	                    <img src="<?php echo base_url('dist/img/clients/pertaminaep.png'); ?>" class="responimg">
	                </a>
	                <!-- <h3> </h3> -->
	                <p></p>
	            </div>
	        </div>
        </center>  
        </div>
		</div>
</div>

<?php $this->load->view('include/foot'); ?>