<?php $this->load->view('include/head'); ?>
<?php $this->load->view('include/navbar'); ?>
<div style="background: #1a47ac">
	<div style="background: rgba(0,0,0,.5);">
		<div class="container">
			<div class="col-md-12" style="margin:5% auto; max-height: 150px;height:100%;">
				<h1><label class="wow fadeInLeft judul-link">Pricing</label></h1>
			</div>
		</div>
	</div>
	
</div>

<div class="aboutus konten1">
	<div class="container">
		<div class="col-md-12" style="margin-top: 2%;">
			

		</div>
	</div>
</div>

<?php $this->load->view('include/foot'); ?>