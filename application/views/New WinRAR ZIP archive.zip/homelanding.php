<?php $this->load->view('include/head'); ?>
<?php $this->load->view('include/navbar'); ?>
<?php $this->load->view('include/home'); ?>
<?php $this->load->view('include/about'); ?>
<?php $this->load->view('include/preview'); ?>
<?php $this->load->view('include/contact'); ?>
<?php $this->load->view('include/foot'); ?>